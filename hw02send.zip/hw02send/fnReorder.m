function [ output_args ] = fnReorder( mat_reorder )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


end

